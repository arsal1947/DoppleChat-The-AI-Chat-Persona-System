# pylint: disable=no-member
import json
from django.shortcuts import render, redirect, get_object_or_404
from django.http import JsonResponse
from django.views.decorators.http import require_http_methods
from django.contrib import messages
from django.core.exceptions import ObjectDoesNotExist
from django.db import DatabaseError
from pydantic import ValidationError


from .models import ChatInfo, SelectedChat, ConversationHistory
from .utils import (
    ChatUploadValidator,
    PersonaSummaryValidator,
    ConversationValidator,
    WhatsAppChatParser,
    GeminiService,
    setup_logger,
    log_to_database
)


logger = setup_logger(__name__)


@require_http_methods(["GET"])
def home_view(request):
    """
    Render the home page with chat list and active chat interface.
    
    Displays all uploaded chat personas and the currently active chat if any.
    """
    try:
        active_chat = None
        try:
            selected = SelectedChat.objects.filter(active=True).first()
            if selected:
                active_chat = selected.chat
        except Exception as e:
            logger.warning("Error fetching active chat: %s", str(e))
        
        chats = ChatInfo.objects.all().order_by('-created_at')
        
        context = {
            'chats': chats,
            'active_chat': active_chat,
        }
        
        logger.info("Home view loaded with %s chats", chats.count())
        return render(request, 'chatapp/home.html', context)
        
    except Exception as e:
        logger.error("Error in home view: %s", str(e))
        log_to_database('ERROR', f'Home view error: {str(e)}', 'views')
        messages.error(request, "An error occurred while loading the page.")
        return render(request, 'chatapp/home.html', {'chats': [], 'active_chat': None})


@require_http_methods(["POST"])
def upload_chat_view(request):
    """
    Handle WhatsApp chat file upload and persona generation.
    
    Validates uploaded file, extracts messages for specified person,
    analyzes writing style, and generates AI persona using Gemini.
    """
    try:
        person_name = request.POST.get('person_name', '').strip()
        uploaded_file = request.FILES.get('chat_file')
        
        if not person_name:
            messages.error(request, "Please enter a person name.")
            return redirect('home')
      
        if not uploaded_file:
            messages.error(request, "Please upload a chat file.")
            return redirect('home')
        
        try:
            file_content = uploaded_file.read().decode('utf-8')
        except UnicodeDecodeError:
            try:
                file_content = uploaded_file.read().decode('utf-16')
            except Exception:
                messages.error(request, "Unable to read file. Please ensure it's a valid text file.")
                log_to_database('ERROR', 'File encoding error during upload', 'views')
                return redirect('home')
        
        try:
            ChatUploadValidator(
                person_name=person_name,
                file_content=file_content,
                file_name=uploaded_file.name
            )
            logger.info("Chat upload validation passed for %s", person_name)
        except ValidationError as ve:
            error_messages = [f"{err['loc'][0]}: {err['msg']}" for err in ve.errors()]
            messages.error(request, f"Validation error: {', '.join(error_messages)}")
            log_to_database('WARNING', f'Upload validation failed: {error_messages}', 'views')
            return redirect('home')
        
        parser = WhatsAppChatParser()
        
        try:
            cleaned_messages, _ = parser.extract_messages(file_content, person_name)
        except ValueError as ve:
            messages.error(request, str(ve))
            return redirect('home')
        except Exception as e:
            messages.error(request, f"Error parsing chat file: {str(e)}")
            return redirect('home')
        
        writing_style = parser.analyze_writing_style(cleaned_messages)
        
        try:
            gemini = GeminiService()
            persona_summary = gemini.generate_persona_summary(
                person_name=person_name,
                messages=cleaned_messages,
                writing_style=writing_style
            )
        except Exception as e:
            messages.error(request, f"Error generating persona: {str(e)}")
            logger.error("Gemini service error: %s", str(e))
            return redirect('home')
        
        try:
            PersonaSummaryValidator(
                person_name=person_name,
                cleaned_messages=cleaned_messages[:10],
                persona_summary=persona_summary,
                message_count=len(cleaned_messages),
                writing_style_indicators=writing_style
            )
            logger.info("Persona summary validation passed")
        except ValidationError as ve:
            error_msg = f"Generated persona didn't meet quality standards: {ve}"
            messages.error(request, error_msg)
            log_to_database('ERROR', error_msg, 'views')
            return redirect('home')
        
        try:
            chat_info = ChatInfo.objects.create(
                person_name=person_name,
                cleaned_chat=json.dumps(cleaned_messages),
                persona_summary=persona_summary,
                raw_file_name=uploaded_file.name
            )
            
            SelectedChat.objects.update(active=False)
            
            SelectedChat.objects.create(
                chat=chat_info,
                active=True
            )
            
            messages.success(request, f"Chat for {person_name} uploaded successfully! You can now chat with their persona.")
            logger.info("Chat created successfully for %s with ID %s", person_name, chat_info.chat_id)
            log_to_database('INFO', f'Chat created for {person_name}', 'views', {
                'chat_id': chat_info.chat_id,
                'message_count': len(cleaned_messages)
            })
            
        except Exception as e:
            messages.error(request, f"Error saving chat to database: {str(e)}")
            logger.error("Database error: %s", str(e))
            log_to_database('ERROR', f'Database save error: {str(e)}', 'views')
            return redirect('home')
        
        return redirect('home')
        
    except Exception as e:
        logger.error("Unexpected error in upload_chat_view: %s", str(e))
        log_to_database('ERROR', f'Unexpected upload error: {str(e)}', 'views')
        messages.error(request, "An unexpected error occurred. Please try again.")
        return redirect('home')


@require_http_methods(["POST"])
def select_chat_view(request, chat_id):
    """
    Set a chat as the active chat for conversation.
    
    Deactivates all other chats and sets the specified chat as active.
    """
    try:
        chat = get_object_or_404(ChatInfo, chat_id=chat_id)
        
        SelectedChat.objects.update(active=False)
        
        SelectedChat.objects.update_or_create(
            chat=chat,
            defaults={'active': True}
        )
        
        logger.info("Chat %s (%s) selected", chat_id, chat.person_name)
        log_to_database('INFO', f'Chat selected: {chat.person_name}', 'views', {'chat_id': chat_id})
        
        return redirect('home')
        
    except Exception as e:
        logger.error("Error selecting chat: %s", str(e))
        log_to_database('ERROR', f'Chat selection error: {str(e)}', 'views')
        messages.error(request, "Error selecting chat.")
        return redirect('home')


@require_http_methods(["POST"])
def delete_chat_view(request, chat_id):
    """
    Delete a chat persona and all associated conversation history.
    
    Permanently removes the chat from the database.
    """
    try:
        chat = get_object_or_404(ChatInfo, chat_id=chat_id)
        person_name = chat.person_name
        
        chat.delete()
        
        messages.success(request, f"Chat for {person_name} deleted successfully.")
        logger.info("Chat %s (%s) deleted", chat_id, person_name)
        log_to_database('INFO', f'Chat deleted: {person_name}', 'views', {'chat_id': chat_id})
        
        return redirect('home')
        
    except Exception as e:
        logger.error("Error deleting chat: %s", str(e))
        log_to_database('ERROR', f'Chat deletion error: {str(e)}', 'views')
        messages.error(request, "Error deleting chat.")
        return redirect('home')


@require_http_methods(["POST"])
def send_message_view(request):
    """
    Process user message and generate AI response.
    
    Uses conversation history and persona summary to generate
    context-aware responses that match the persona's style.
    """
    try:
        data = json.loads(request.body)
        user_message = data.get('message', '').strip()
        
        if not user_message:
            return JsonResponse({'error': 'Message cannot be empty'}, status=400)
        
        try:
            selected = SelectedChat.objects.filter(active=True).first()
            if not selected:
                return JsonResponse({'error': 'No chat selected. Please upload and select a chat first.'}, status=400)
            
            chat = selected.chat
        except Exception as e:
            logger.error("Error fetching active chat: %s", str(e))
            return JsonResponse({'error': 'Error fetching active chat'}, status=500)
        
        try:
            conversation_history = list(
                ConversationHistory.objects
                .filter(chat=chat)
                .order_by('timestamp')
                .values('user_message', 'ai_response')
            )
        except Exception as e:
            logger.error("Error fetching conversation history: %s", str(e))
            conversation_history = []
        
        try:
            gemini = GeminiService()
            ai_response = gemini.generate_response(
                user_message=user_message,
                persona_summary=chat.persona_summary,
                conversation_history=conversation_history,
                person_name=chat.person_name
            )
        except Exception as e:
            logger.error("Error generating AI response: %s", str(e))
            return JsonResponse({'error': f'Error generating response: {str(e)}'}, status=500)
        
        try:
            ConversationValidator(
                user_message=user_message,
                ai_response=ai_response,
                chat_id=chat.chat_id
            )
            logger.info("Conversation validation passed")
        except ValidationError as ve:
            logger.warning("Conversation validation warning: %s", ve)
        
        try:
            ConversationHistory.objects.create(
                chat=chat,
                user_message=user_message,
                ai_response=ai_response
            )
            
            logger.info("Message saved for chat %s", chat.chat_id)
            log_to_database('INFO', f'Message exchanged in chat {chat.person_name}', 'views', {
                'chat_id': chat.chat_id,
                'user_message_length': len(user_message),
                'ai_response_length': len(ai_response)
            })
            
        except Exception as e:
            logger.error("Error saving conversation: %s", str(e))
        
        return JsonResponse({
            'success': True,
            'response': ai_response,
            'persona_name': chat.person_name
        })
        
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON'}, status=400)
    except Exception as e:
        logger.error("Unexpected error in send_message_view: %s", str(e))
        log_to_database('ERROR', f'Message send error: {str(e)}', 'views')
        return JsonResponse({'error': 'An unexpected error occurred'}, status=500)


@require_http_methods(["GET"])
def get_messages_view(_request, chat_id):
    """
    Retrieve conversation history for a specific chat.
    
    Returns all user messages and AI responses in chronological order.
    """
    try:
        chat = get_object_or_404(ChatInfo, chat_id=chat_id)
        
        messages_list = ConversationHistory.objects.filter(
            chat=chat
        ).order_by('timestamp').values(
            'user_message', 'ai_response', 'timestamp'
        )
        
        return JsonResponse({
            'success': True,
            'messages': list(messages_list),
            'persona_name': chat.person_name
        })
        
    except (ObjectDoesNotExist, DatabaseError) as e:
        logger.error("Error fetching messages: %s", str(e))
        return JsonResponse({'error': 'Error fetching messages'}, status=500)
    except Exception as e:
        logger.error("Unexpected error in get_messages_view: %s", str(e))
        return JsonResponse({'error': 'An unexpected error occurred'}, status=500)
