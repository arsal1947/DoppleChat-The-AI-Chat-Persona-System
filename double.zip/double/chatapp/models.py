# pylint: disable=no-member
from django.db import models
from django.utils import timezone


class ChatInfo(models.Model):
    chat_id = models.AutoField(primary_key=True)
    person_name = models.CharField(max_length=200)
    cleaned_chat = models.TextField()
    persona_summary = models.TextField()
    raw_file_name = models.CharField(max_length=255)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'chat_info'
        ordering = ['-created_at']
    
    def __str__(self):
        return f"{self.person_name} - Chat {self.chat_id}"


class SelectedChat(models.Model):
    id = models.AutoField(primary_key=True)
    chat = models.ForeignKey(ChatInfo, on_delete=models.CASCADE, related_name='selections')
    active = models.BooleanField(default=False)
    selected_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        db_table = 'selected_chat'
    
    def __str__(self):
        return f"Selection for {self.chat.person_name} - Active: {self.active}"


class ConversationHistory(models.Model):
    id = models.AutoField(primary_key=True)
    chat = models.ForeignKey(ChatInfo, on_delete=models.CASCADE, related_name='conversations')
    user_message = models.TextField()
    ai_response = models.TextField()
    timestamp = models.DateTimeField(default=timezone.now)
    
    class Meta:
        db_table = 'conversation_history'
        ordering = ['timestamp']
    
    def __str__(self):
        return f"Conversation for {self.chat.person_name} at {self.timestamp}"


class SystemLog(models.Model):
    id = models.AutoField(primary_key=True)
    level = models.CharField(max_length=20)
    message = models.TextField()
    module = models.CharField(max_length=100)
    timestamp = models.DateTimeField(default=timezone.now)
    extra_data = models.JSONField(null=True, blank=True)
    
    class Meta:
        db_table = 'system_logs'
        ordering = ['-timestamp']
    
    def __str__(self):
        return f"[{self.level}] {self.module} - {self.timestamp}"
