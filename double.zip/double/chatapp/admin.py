from django.contrib import admin
from .models import ChatInfo, SelectedChat, ConversationHistory, SystemLog


@admin.register(ChatInfo)
class ChatInfoAdmin(admin.ModelAdmin):
    list_display = ('chat_id', 'person_name', 'raw_file_name', 'created_at', 'updated_at')
    list_filter = ('created_at', 'updated_at')
    search_fields = ('person_name', 'raw_file_name')
    readonly_fields = ('chat_id', 'created_at', 'updated_at')
    fieldsets = (
        ('Basic Information', {
            'fields': ('chat_id', 'person_name', 'raw_file_name')
        }),
        ('Chat Data', {
            'fields': ('cleaned_chat', 'persona_summary')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at')
        }),
    )


@admin.register(SelectedChat)
class SelectedChatAdmin(admin.ModelAdmin):
    list_display = ('id', 'chat', 'active', 'selected_at')
    list_filter = ('active', 'selected_at')
    readonly_fields = ('selected_at',)


@admin.register(ConversationHistory)
class ConversationHistoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'chat', 'user_message_preview', 'timestamp')
    list_filter = ('timestamp', 'chat')
    search_fields = ('user_message', 'ai_response')
    readonly_fields = ('timestamp',)
    
    def user_message_preview(self, obj):
        return obj.user_message[:50] + '...' if len(obj.user_message) > 50 else obj.user_message
    user_message_preview.short_description = 'User Message'


@admin.register(SystemLog)
class SystemLogAdmin(admin.ModelAdmin):
    list_display = ('id', 'level', 'module', 'message_preview', 'timestamp')
    list_filter = ('level', 'module', 'timestamp')
    search_fields = ('message', 'module')
    readonly_fields = ('timestamp',)
    
    def message_preview(self, obj):
        return obj.message[:50] + '...' if len(obj.message) > 50 else obj.message
    message_preview.short_description = 'Message'
