from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('upload/', views.upload_chat_view, name='upload_chat'),
    path('select/<int:chat_id>/', views.select_chat_view, name='select_chat'),
    path('delete/<int:chat_id>/', views.delete_chat_view, name='delete_chat'),
    path('send-message/', views.send_message_view, name='send_message'),
    path('messages/<int:chat_id>/', views.get_messages_view, name='get_messages'),
]

