import re
from typing import List, Dict, Tuple, Optional
from .logger import setup_logger, log_to_database


class WhatsAppParserError(Exception):
    """Custom exception for WhatsApp parser errors"""


logger = setup_logger(__name__)


class WhatsAppChatParser:
    
    PATTERNS = [
        r'\[(\d{1,2}/\d{1,2}/\d{2,4}),?\s+(\d{1,2}:\d{2}:\d{2}\s*[AP]M)\]\s*([^:]+):\s*(.*)',
        r'(\d{1,2}/\d{1,2}/\d{2,4}),?\s+(\d{1,2}:\d{2}\s*[AP]M)\s*-\s*([^:]+):\s*(.*)',
        r'(\d{1,2}/\d{1,2}/\d{2,4}),?\s+(\d{1,2}:\d{2})\s*-\s*([^:]+):\s*(.*)',
    ]
    
    def __init__(self):
        self.logger = logger
    
    def validate_whatsapp_format(self, content: str) -> bool:
        try:
            lines = content.strip().split('\n')
            if len(lines) < 3:
                self.logger.warning("File has less than 3 lines")
                return False
            
            valid_lines = 0
            for line in lines[:10]:
                for pattern in self.PATTERNS:
                    if re.match(pattern, line.strip()):
                        valid_lines += 1
                        break
            
            is_valid = valid_lines >= 2
            if not is_valid:
                self.logger.warning("Only %s valid WhatsApp format lines found in first 10 lines", valid_lines)
            
            return is_valid
            
        except (AttributeError, IndexError, TypeError) as e:
            self.logger.error("Error validating WhatsApp format: %s", str(e))
            log_to_database('ERROR', f'WhatsApp format validation failed: {str(e)}', 'whatsapp_parser')
            return False
        except Exception as e:
            self.logger.error("Unexpected error in validate_whatsapp_format: %s", str(e))
            log_to_database('ERROR', f'Unexpected validation error: {str(e)}', 'whatsapp_parser')
            return False
    
    def extract_messages(self, content: str, person_name: str) -> Tuple[List[str], Dict]:
        try:
            if not self.validate_whatsapp_format(content):
                raise ValueError("Invalid WhatsApp chat format. Please upload a valid exported WhatsApp chat file.")
            
            lines = content.strip().split('\n')
            messages = []
            current_message: Optional[Dict[str, str]] = None
            stats = {
                'total_lines': len(lines),
                'person_message_count': 0,
                'other_message_count': 0,
                'system_message_count': 0
            }
            
            for line in lines:
                line = line.strip()
                if not line:
                    continue
                
                matched = False
                for pattern in self.PATTERNS:
                    match = re.match(pattern, line)
                    if match:
                        matched = True
                        groups = match.groups()
                        sender = groups[2].strip()
                        message_text = groups[3].strip()
                        
                        if current_message and current_message['sender'] == person_name:  # pylint: disable=unsubscriptable-object
                            messages.append(current_message['text'])  # pylint: disable=unsubscriptable-object
                        
                        current_message = {
                            'sender': sender,
                            'text': message_text
                        }
                        
                        if sender == person_name:
                            stats['person_message_count'] += 1
                        elif '<Media omitted>' not in message_text and 'This message was deleted' not in message_text:
                            stats['other_message_count'] += 1
                        else:
                            stats['system_message_count'] += 1
                        
                        break
                
                if not matched and current_message:
                    current_message['text'] += ' ' + line  # pylint: disable=unsubscriptable-object
            
            if current_message and current_message['sender'] == person_name:  # pylint: disable=unsubscriptable-object
                messages.append(current_message['text'])  # pylint: disable=unsubscriptable-object
            
            if not messages:
                raise ValueError(f"No messages found for person '{person_name}'. Please check the name and ensure it matches exactly as it appears in the chat.")
            
            cleaned_messages = self.clean_messages(messages)
            
            self.logger.info("Extracted %s messages for %s", len(cleaned_messages), person_name)
            log_to_database('INFO', f'Successfully extracted {len(cleaned_messages)} messages for {person_name}', 'whatsapp_parser', stats)
            
            return cleaned_messages, stats
            
        except ValueError as ve:
            self.logger.error("Validation error: %s", str(ve))
            log_to_database('ERROR', str(ve), 'whatsapp_parser')
            raise
        except (AttributeError, IndexError, KeyError) as e:
            self.logger.error("Error extracting messages: %s", str(e))
            log_to_database('ERROR', f'Message extraction failed: {str(e)}', 'whatsapp_parser')
            raise WhatsAppParserError(f"Failed to parse WhatsApp chat: {str(e)}") from e
        except Exception as e:
            self.logger.error("Unexpected error in extract_messages: %s", str(e))
            log_to_database('ERROR', f'Unexpected extraction error: {str(e)}', 'whatsapp_parser')
            raise WhatsAppParserError(f"Failed to parse WhatsApp chat: {str(e)}") from e
    
    def clean_messages(self, messages: List[str]) -> List[str]:
        try:
            cleaned = []
            for msg in messages:
                if '<Media omitted>' in msg or 'This message was deleted' in msg:
                    continue
                
                msg = re.sub(r'http[s]?://(?:[a-zA-Z]|[0-9]|[$-_@.&+]|[!*\\(\\),]|(?:%[0-9a-fA-F][0-9a-fA-F]))+', '[URL]', msg)
                
                msg = msg.strip()
                
                if msg and len(msg) > 0:
                    cleaned.append(msg)
            
            return cleaned
            
        except (AttributeError, TypeError) as e:
            self.logger.error("Error cleaning messages: %s", str(e))
            return messages
        except Exception as e:
            self.logger.error("Unexpected error in clean_messages: %s", str(e))
            return messages
    
    def analyze_writing_style(self, messages: List[str]) -> Dict:
        try:
            if not messages:
                return {}
            
            total_chars = sum(len(msg) for msg in messages)
            avg_length = total_chars / len(messages) if messages else 0
            
            emoji_count = sum(msg.count(emoji) for msg in messages 
                            for emoji in ['😊', '😂', '❤️', '👍', '😭', '🤣', '💯', '🔥'])
            
            question_count = sum(1 for msg in messages if '?' in msg)
            exclamation_count = sum(1 for msg in messages if '!' in msg)
            
            return {
                'avg_message_length': round(avg_length, 2),
                'total_messages': len(messages),
                'emoji_usage': 'high' if emoji_count > len(messages) * 0.3 else 'medium' if emoji_count > 0 else 'low',
                'question_percentage': round((question_count / len(messages)) * 100, 2),
                'exclamation_percentage': round((exclamation_count / len(messages)) * 100, 2),
                'total_characters': total_chars
            }
            
        except (AttributeError, ZeroDivisionError, TypeError) as e:
            self.logger.error("Error analyzing writing style: %s", str(e))
            return {}
        except Exception as e:
            self.logger.error("Unexpected error in analyze_writing_style: %s", str(e))
            return {}

