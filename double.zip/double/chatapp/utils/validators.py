from pydantic import BaseModel, Field, field_validator
from typing import List, Optional
from datetime import datetime


class ChatUploadValidator(BaseModel):
    person_name: str = Field(..., min_length=1, max_length=200, description="Name of person whose chat to extract")
    file_content: str = Field(..., min_length=10, description="Content of uploaded WhatsApp chat file")
    file_name: str = Field(..., min_length=1, max_length=255, description="Original filename")
    
    @field_validator('person_name')
    @classmethod
    def validate_person_name(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("Person name cannot be empty or whitespace only")
        return value.strip()
    
    @field_validator('file_content')
    @classmethod
    def validate_file_content(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("File content cannot be empty")
        lines = value.strip().split('\n')
        if len(lines) < 3:
            raise ValueError("File appears to be too short to be a valid WhatsApp chat export")
        return value


class PersonaSummaryValidator(BaseModel):
    person_name: str = Field(..., min_length=1, max_length=200)
    cleaned_messages: List[str] = Field(..., min_items=1, description="Extracted messages from person")
    persona_summary: str = Field(..., min_length=50, description="Generated persona summary")
    message_count: int = Field(..., ge=1, description="Number of messages extracted")
    writing_style_indicators: Optional[dict] = Field(default=None, description="Writing style analysis")
    
    @field_validator('persona_summary')
    @classmethod
    def validate_persona_summary(cls, value: str) -> str:
        if len(value) < 50:
            raise ValueError("Persona summary must be at least 50 characters long")
        required_keywords = ['style', 'tone', 'personality']
        if not any(keyword in value.lower() for keyword in required_keywords):
            raise ValueError("Persona summary must describe style, tone, or personality")
        return value
    
    class Config:
        json_schema_extra = {
            "example": {
                "person_name": "Ahmad",
                "cleaned_messages": ["Hello how are you", "I am doing great"],
                "persona_summary": "Ahmad has a casual and friendly communication style...",
                "message_count": 2,
                "writing_style_indicators": {"emoji_usage": "high", "avg_message_length": 15}
            }
        }


class ConversationValidator(BaseModel):
    user_message: str = Field(..., min_length=1, max_length=5000, description="User's message")
    ai_response: str = Field(..., min_length=1, description="AI generated response")
    chat_id: int = Field(..., ge=1, description="Associated chat ID")
    timestamp: datetime = Field(default_factory=datetime.now)
    response_quality_score: Optional[float] = Field(default=None, ge=0.0, le=1.0, description="Quality score of response")
    
    @field_validator('user_message')
    @classmethod
    def validate_user_message(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("User message cannot be empty")
        return value.strip()
    
    @field_validator('ai_response')
    @classmethod
    def validate_ai_response(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("AI response cannot be empty")
        if len(value) < 1:
            raise ValueError("AI response appears to be too short")
        return value.strip()
    
    class Config:
        json_schema_extra = {
            "example": {
                "user_message": "How are you today?",
                "ai_response": "I'm doing great, thanks for asking!",
                "chat_id": 1,
                "response_quality_score": 0.95
            }
        }

