# pylint: disable=no-member
import logging
from logging.handlers import RotatingFileHandler
import os
from typing import Optional, Dict, Any


def setup_logger(name: str, log_file: str = 'dopplechat.log', level=logging.INFO):
    logger = logging.getLogger(name)
    logger.setLevel(level)
    
    if logger.handlers:
        return logger
    
    logs_dir = 'logs'
    if not os.path.exists(logs_dir):
        os.makedirs(logs_dir)
    
    log_path = os.path.join(logs_dir, log_file)
    
    file_handler = RotatingFileHandler(
        log_path,
        maxBytes=10*1024*1024,
        backupCount=5,
        encoding='utf-8'
    )
    file_handler.setLevel(level)
    
    console_handler = logging.StreamHandler()
    console_handler.setLevel(level)
    
    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)
    
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)
    
    return logger


def log_to_database(level: str, message: str, module: str, extra_data: Optional[Dict[str, Any]] = None):
    try:
        from chatapp.models import SystemLog
        SystemLog.objects.create(
            level=level,
            message=message,
            module=module,
            extra_data=extra_data or {}
        )
    except (ImportError, AttributeError) as e:
        logger = logging.getLogger(__name__)
        logger.error("Failed to log to database: %s", str(e))
    except Exception as e:
        logger = logging.getLogger(__name__)
        logger.error("Unexpected error in log_to_database: %s", str(e))

