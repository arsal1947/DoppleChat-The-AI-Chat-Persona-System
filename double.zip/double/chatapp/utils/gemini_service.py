import google.generativeai as genai
from typing import List, Dict, Optional
import os
import json
from dotenv import load_dotenv
from .logger import setup_logger, log_to_database


load_dotenv()

logger = setup_logger(__name__)


class GeminiService:
    
    def __init__(self):
        # self.api_key = os.getenv('GEMINI_API_KEY')
        self.api_key = "Your_API_KEY"
        # if not self.api_key or self.api_key == 'your_gemini_api_key_here':
        #     logger.warning("Gemini API key not configured properly")
        #     raise ValueError(f"Please set GEMINI_API_KEY in .env file {self.api_key}")
        
        try:
            genai.configure(api_key=self.api_key)
            self.model = genai.GenerativeModel('gemini-2.5-flash')
            logger.info("Gemini service initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize Gemini service: {str(e)}")
            log_to_database('ERROR', f'Gemini initialization failed: {str(e)}', 'gemini_service')
            raise
    
    def generate_persona_summary(self, person_name: str, messages: List[str], writing_style: Dict) -> str:
        try:
            # Use all messages instead of just sample for better analysis
            cleaned_chat_text = chr(10).join(messages)

            prompt = f"""
You are an expert linguist and behavioral psychologist specializing in digital communication analysis.

CRITICAL: Extract ONLY from the ACTUAL messages provided. DO NOT use generic examples.

TASK: Create a HIGHLY DETAILED profile of "{person_name}" by analyzing their REAL WhatsApp messages.

ANALYSIS FOCUS AREAS:

1. VOCABULARY & LANGUAGE PATTERNS:
   - Extract 15-20 MOST FREQUENTLY used words from ACTUAL messages (exact words they use, with frequency)
   - Identify REAL signature phrases they repeat (minimum 3 occurrences)
   - Document their actual code-switching patterns
   - Note REAL slang, abbreviations they actually use

2. BEHAVIORAL COMMUNICATION STYLE:
   - How do THEY express agreement? (extract from messages)
   - How do THEY express disagreement or frustration? (extract from messages)
   - How do THEY show excitement or happiness? (extract from messages)
   - How do THEY express sadness or disappointment? (extract from messages)

3. DIALOGUE & EXPRESSION FAVORITES:
   - List 8-10 signature phrases THEY actually use (EXACT wording from messages)
   - Include THEIR typical reactions found in messages
   - THEIR go-to expressions when surprised, confused, or thinking

4. EMOJI & SYMBOL USAGE:
   - Top 5-8 emojis THEY actually use (from messages only)
   - Count and rank by frequency

MESSAGES FROM {person_name}:

{cleaned_chat_text}

Return ONLY valid JSON with ACTUAL extracted data (no markdown, no code blocks):

{{
  "target_person_name": "{person_name}",

  "core_personality": {{
    "traits": ["extracted trait 1", "trait 2", "trait 3", "trait 4", "trait 5"],
    "communication_style": "detailed description based on actual messages",
    "overall_tone": "analyze from messages",
    "expressiveness_level": "analyze from messages"
  }},

  "language_profile": {{
    "primary_language": "detected from messages",
    "code_switching_pattern": "description from actual usage",
    "most_used_words": [
      {{"word": "ACTUAL word from chat", "frequency": "count/percentage", "context": "how they use it"}},
      {{"word": "ACTUAL word 2", "frequency": "count", "context": "usage context"}},
      {{"word": "ACTUAL word 3", "frequency": "count", "context": "usage context"}}
    ],
    "vocabulary_level": "analyze from messages"
  }},

  "signature_expressions": {{
    "favorite_phrases": [
      {{"phrase": "EXACT phrase from messages", "usage_context": "when they say this", "frequency": "how often"}},
      {{"phrase": "EXACT phrase 2", "usage_context": "context", "frequency": "count"}}
    ],
    "agreement_expressions": ["ACTUAL expressions from chat", "ACTUAL expression 2"],
    "disagreement_expressions": ["ACTUAL expressions from chat"],
    "excitement_expressions": ["ACTUAL expressions from chat"],
    "confusion_expressions": ["ACTUAL expressions from chat"],
    "thinking_fillers": ["ACTUAL fillers from chat like umm, matlab, etc"]
  }},

  "typing_style": {{
    "message_length": "analyze from actual messages",
    "message_frequency": "observe from chat pattern",
    "capitalization": "observe actual usage",
    "punctuation_habits": "observe actual usage",
    "special_characters": ["list actual patterns observed"],
    "typos_pattern": "analyze from messages"
  }},

  "emoji_behavior": {{
    "usage_frequency": "count from messages",
    "favorite_emojis": [
      {{"emoji": "ACTUAL emoji used", "context": "when they use it", "frequency": "count"}},
      {{"emoji": "ACTUAL emoji 2", "context": "usage", "frequency": "count"}}
    ],
    "emoji_placement": "observe from messages",
    "emoji_patterns": "observe from messages"
  }},

  "conversation_patterns": {{
    "greeting_styles": [
      {{"greeting": "ACTUAL greeting from chat", "context": "when used"}},
      {{"greeting": "ACTUAL greeting 2", "context": "when used"}}
    ],
    "farewell_styles": [
      {{"farewell": "ACTUAL farewell from chat", "context": "when used"}}
    ],
    "question_asking_style": "analyze from actual questions in chat",
    "response_style": "analyze from actual responses"
  }},

  "emotional_expression": {{
    "happiness": "description with ACTUAL example phrases from chat",
    "sadness": "description with ACTUAL example phrases from chat",
    "anger": "description with ACTUAL example phrases from chat",
    "surprise": "description with ACTUAL example phrases from chat",
    "sarcasm_usage": "analyze with ACTUAL examples",
    "humor_style": "analyze from messages"
  }},

  "unique_identifiers": [
    "specific REAL pattern 1 from messages",
    "specific REAL phrase that is signature",
    "unique REAL habit observed"
  ],

  "do_not_overuse": [
    "phrases that appear but should be used sparingly for authenticity"
  ],

  "response_guidelines": {{
    "when_to_be_brief": "observed patterns of brief replies",
    "when_to_elaborate": "observed patterns of detailed responses",
    "natural_flow": "maintain rhythm observed in chat",
    "avoid_forcing": "use signature phrases only when contextually natural"
  }},

  "comprehensive_summary": "First-person 4-5 sentence description based on ACTUAL communication patterns observed"
}}

REMEMBER: Extract ONLY from actual messages. DO NOT invent or use generic examples.
"""

            logger.info(f"Generating detailed persona summary for {person_name}")

            response = self.model.generate_content(prompt)

            if not response or not response.text:
                raise Exception("Empty response from Gemini API")

            # Clean the response to extract JSON
            response_text = response.text.strip()

            # Remove markdown code blocks if present
            if response_text.startswith('```json'):
                response_text = response_text[7:]
            if response_text.startswith('```'):
                response_text = response_text[3:]
            if response_text.endswith('```'):
                response_text = response_text[:-3]

            response_text = response_text.strip()

            # Validate JSON structure
            try:
                persona_data = json.loads(response_text)
                logger.info(f"Successfully parsed persona JSON for {person_name}")
            except json.JSONDecodeError as e:
                logger.warning(f"JSON parsing failed, using raw response: {str(e)}")
                persona_data = {"comprehensive_summary": response_text}

            # Convert back to string for storage (keeping the JSON structure)
            persona_summary = json.dumps(persona_data, ensure_ascii=False, indent=2)

            logger.info(f"Successfully generated persona summary for {person_name} ({len(persona_summary)} chars)")
            log_to_database('INFO', f'Persona summary generated for {person_name}', 'gemini_service', {
                'summary_length': len(persona_summary),
                'messages_analyzed': len(messages),
                'json_structure': 'detailed_persona_profile'
            })

            return persona_summary
            
        except Exception as e:
            logger.error(f"Error generating persona summary: {str(e)}")
            log_to_database('ERROR', f'Persona summary generation failed: {str(e)}', 'gemini_service')
            raise Exception(f"Failed to generate persona summary: {str(e)}")
    
    def generate_response(self, user_message: str, persona_summary: str, conversation_history: List[Dict[str, str]], person_name: str) -> str:
        try:
            history_text = ""
            if conversation_history:
                recent_history = conversation_history[-10:]
                history_text = "\n".join([
                    f"User: {conv['user_message']}\n{person_name}: {conv['ai_response']}"
                    for conv in recent_history
                ])

            # Build prompt exactly like .NET implementation - pass full persona summary
            prompt = f"""
You must roleplay as this exact person on WhatsApp. Match their style 100% accurately.

PERSONA DETAILS:

{persona_summary}

CRITICAL INSTRUCTIONS:
- Use their exact phrases, words, and expressions
- Match their emoji usage pattern precisely
- Follow their punctuation and typing style
- Keep response length similar to their usual style
- Use their language mix (Hinglish/Urdu/English) exactly as they do
- Mimic any typos or abbreviations they typically use
- Match their tone and emotional expression style

Conversation History:
{history_text if history_text else "This is the start of the conversation."}

USER MESSAGE: {user_message}

Reply as them (ONLY the message, no explanations):
"""

            logger.info(f"Generating response as {person_name} with full persona summary")

            response = self.model.generate_content(prompt)

            if not response or not response.text:
                raise Exception("Empty response from Gemini API")

            ai_response = response.text.strip()

            logger.info(f"Successfully generated response as {person_name} ({len(ai_response)} chars)")
            log_to_database('INFO', f'Response generated as {person_name} with full persona data', 'gemini_service', {
                'response_length': len(ai_response),
                'user_message_length': len(user_message),
                'persona_data_format': 'full_json_structure'
            })

            return ai_response
            
        except Exception as e:
            logger.error(f"Error generating response: {str(e)}")
            log_to_database('ERROR', f'Response generation failed: {str(e)}', 'gemini_service')
            raise Exception(f"Failed to generate response: {str(e)}")
    
    def classify_message_intent(self, message: str) -> str:
        try:
            prompt = f"""
Classify the intent of the following message into ONE of these categories:
- greeting
- question
- statement
- emotion
- request
- farewell
- other

Message: "{message}"

Respond with only the category name, nothing else.
"""
            
            response = self.model.generate_content(prompt)
            intent = response.text.strip().lower()
            
            logger.info(f"Message classified as: {intent}")
            return intent
            
        except Exception as e:
            logger.error(f"Error classifying message: {str(e)}")
            return "other"

