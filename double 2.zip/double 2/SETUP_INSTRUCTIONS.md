# DoppleChat - Complete Setup Instructions

## Quick Start (5 Minutes)

### Step 1: Configure Gemini API Key
1. Get API key from: https://makersuite.google.com/app/apikey
2. Edit `.env` file and replace:
   ```
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
   with your actual API key:
   ```
   GEMINI_API_KEY=AIzaSyC...your_actual_key
   ```

### Step 2: Activate Virtual Environment
```bash
# Windows PowerShell
.\venv\Scripts\activate

# Windows CMD
venv\Scripts\activate.bat

# Linux/Mac
source venv/bin/activate
```

### Step 3: Start Server
```bash
python manage.py runserver
```

### Step 4: Open Browser
Go to: http://127.0.0.1:8000/

### Step 5: Test with Sample Chat
1. Click "Upload Chat"
2. Enter name: `Sara`
3. Select file: `sample_chat.txt`
4. Click Upload
5. Wait 5-10 seconds for processing
6. Start chatting!

---

## Detailed Setup Guide

### Prerequisites Check
```bash
# Check Python version (should be 3.10+)
python --version

# Check pip
pip --version

# Check virtual environment
.\venv\Scripts\activate
python -c "import django; print(django.VERSION)"
```

### If Starting Fresh

#### 1. Create Virtual Environment
```bash
python -m venv venv
```

#### 2. Activate Environment
```bash
.\venv\Scripts\activate
```

#### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

#### 4. Apply Migrations
```bash
python manage.py makemigrations
python manage.py migrate
```

#### 5. Create Superuser (Optional)
```bash
python manage.py createsuperuser
# Enter username, email, password
```

#### 6. Configure .env
```bash
# Edit .env file with your API key
GEMINI_API_KEY=your_actual_key
SECRET_KEY=your_secret_key
DEBUG=True
```

#### 7. Test Server
```bash
python manage.py runserver
```

---

## Project File Overview

### Core Files
- `manage.py` - Django management script
- `db.sqlite3` - SQLite database
- `.env` - Environment variables (API keys)
- `requirements.txt` - Python dependencies

### Configuration
- `dopplechat/settings.py` - Django settings
- `dopplechat/urls.py` - Main URL routing

### Application
- `chatapp/models.py` - Database models (4 tables)
- `chatapp/views.py` - View functions with error handling
- `chatapp/urls.py` - App URL routing
- `chatapp/admin.py` - Admin interface

### Utilities
- `chatapp/utils/validators.py` - Pydantic models (3)
- `chatapp/utils/whatsapp_parser.py` - Chat parser
- `chatapp/utils/gemini_service.py` - AI integration
- `chatapp/utils/logger.py` - Logging system

### Templates
- `chatapp/templates/chatapp/base.html` - Base template
- `chatapp/templates/chatapp/home.html` - Main interface

### Documentation
- `README.md` - Main documentation
- `PROJECT_GUIDE.md` - Quick reference
- `TECHNICAL_REPORT_GUIDE.md` - Report writing guide
- `PRESENTATION_SLIDES_GUIDE.md` - Presentation guide
- `SETUP_INSTRUCTIONS.md` - This file

### Sample Data
- `sample_chat.txt` - Sample WhatsApp chat for testing

---

## Common Issues & Solutions

### Issue 1: Module Not Found
```
Error: ModuleNotFoundError: No module named 'django'
```
**Solution:**
```bash
.\venv\Scripts\activate
pip install -r requirements.txt
```

### Issue 2: API Key Error
```
Error: Please set GEMINI_API_KEY in .env file
```
**Solution:**
- Edit `.env` file
- Add your Gemini API key
- Restart server

### Issue 3: Database Error
```
Error: no such table: chat_info
```
**Solution:**
```bash
python manage.py migrate
```

### Issue 4: Port In Use
```
Error: That port is already in use.
```
**Solution:**
```bash
# Use different port
python manage.py runserver 8001

# Or kill process using port 8000
# Windows:
netstat -ano | findstr :8000
taskkill /PID <PID> /F

# Linux/Mac:
lsof -ti:8000 | xargs kill -9
```

### Issue 5: Static Files Not Loading
```
Error: Static files not found
```
**Solution:**
```bash
python manage.py collectstatic --noinput
```

### Issue 6: Import Error in Views
```
Error: cannot import name 'X' from 'chatapp.utils'
```
**Solution:**
- Check if all utils files exist
- Verify `__init__.py` has correct imports
- Restart server

### Issue 7: Gemini API Error
```
Error: 429 Too Many Requests
```
**Solution:**
- Wait a few minutes
- Check API quota
- Verify API key is valid

---

## Testing Checklist

### Basic Functionality
- [ ] Server starts without errors
- [ ] Homepage loads correctly
- [ ] Upload modal opens
- [ ] Can upload sample_chat.txt
- [ ] Chat appears in sidebar
- [ ] Can select chat
- [ ] Can send messages
- [ ] AI responds correctly
- [ ] Can delete chat

### Error Handling
- [ ] Upload with wrong name shows error
- [ ] Upload invalid file shows error
- [ ] Empty message shows error
- [ ] No selected chat shows error

### Database
- [ ] Chats saved to database
- [ ] Conversations saved
- [ ] Logs created
- [ ] Can view in admin panel

### UI/UX
- [ ] Responsive on different screens
- [ ] Animations work smoothly
- [ ] Modals open/close
- [ ] Messages display correctly
- [ ] Sidebar scrolls properly

---

## Development Workflow

### Making Changes

1. **Edit Code**
   ```bash
   # Make changes to files
   ```

2. **Test Changes**
   ```bash
   python manage.py runserver
   # Test in browser
   ```

3. **Check Logs**
   ```bash
   # View file logs
   type logs\dopplechat.log    # Windows
   cat logs/dopplechat.log     # Linux/Mac
   
   # View database logs
   python manage.py shell
   >>> from chatapp.models import SystemLog
   >>> SystemLog.objects.latest('timestamp')
   ```

4. **Database Changes**
   ```bash
   # If models changed
   python manage.py makemigrations
   python manage.py migrate
   ```

### Adding New Features

1. **Create Model** (if needed)
   - Edit `chatapp/models.py`
   - Run migrations

2. **Create Validator** (if needed)
   - Edit `chatapp/utils/validators.py`
   - Add Pydantic model

3. **Create View**
   - Edit `chatapp/views.py`
   - Add error handling
   - Add logging

4. **Add URL**
   - Edit `chatapp/urls.py`
   - Map view to URL

5. **Create Template** (if needed)
   - Edit templates
   - Add Tailwind classes

6. **Test**
   - Run server
   - Test feature
   - Check logs

---

## Deployment (Optional)

### For Local Demo
Current setup is perfect for local demo and presentation.

### For Production (Future)
1. Set `DEBUG=False` in `.env`
2. Set strong `SECRET_KEY`
3. Configure `ALLOWED_HOSTS`
4. Use PostgreSQL instead of SQLite
5. Configure static files properly
6. Set up HTTPS
7. Use environment-specific settings

---

## Database Management

### View Database
```bash
# Open SQLite shell
python manage.py dbshell

# View tables
.tables

# View schema
.schema chat_info

# Query data
SELECT * FROM chat_info;
SELECT * FROM conversation_history LIMIT 10;
SELECT * FROM system_logs ORDER BY timestamp DESC LIMIT 10;

# Exit
.quit
```

### Backup Database
```bash
# Windows
copy db.sqlite3 db_backup.sqlite3

# Linux/Mac
cp db.sqlite3 db_backup.sqlite3
```

### Reset Database
```bash
# Careful: This deletes all data!
del db.sqlite3                    # Windows
rm db.sqlite3                     # Linux/Mac
python manage.py migrate
```

---

## Admin Panel

### Access Admin
1. Create superuser (if not done):
   ```bash
   python manage.py createsuperuser
   ```

2. Start server:
   ```bash
   python manage.py runserver
   ```

3. Go to: http://127.0.0.1:8000/admin/

4. Login with superuser credentials

### Admin Features
- View all chats
- Edit persona summaries
- View conversation history
- View system logs
- Delete records
- Filter and search

---

## Logging

### File Logs
```bash
# View all logs
type logs\dopplechat.log         # Windows
cat logs/dopplechat.log          # Linux/Mac

# View last 50 lines
Get-Content logs\dopplechat.log -Tail 50    # Windows PowerShell
tail -50 logs/dopplechat.log                # Linux/Mac

# View errors only
findstr "ERROR" logs\dopplechat.log         # Windows
grep "ERROR" logs/dopplechat.log            # Linux/Mac
```

### Database Logs
```bash
python manage.py shell
```
```python
from chatapp.models import SystemLog

# View recent logs
for log in SystemLog.objects.all()[:10]:
    print(f"{log.timestamp} - {log.level} - {log.message}")

# View errors
for log in SystemLog.objects.filter(level='ERROR'):
    print(f"{log.timestamp} - {log.module} - {log.message}")

# View logs for specific module
for log in SystemLog.objects.filter(module='gemini_service'):
    print(f"{log.timestamp} - {log.message}")
```

---

## Performance Tips

### Optimize Database
```bash
python manage.py shell
```
```python
from django.db import connection
connection.cursor().execute("VACUUM")
```

### Clear Old Logs
```python
from chatapp.models import SystemLog
from datetime import datetime, timedelta

# Delete logs older than 7 days
old_date = datetime.now() - timedelta(days=7)
SystemLog.objects.filter(timestamp__lt=old_date).delete()
```

### Monitor Performance
```python
import time

start = time.time()
# Your code here
end = time.time()
print(f"Execution time: {end - start} seconds")
```

---

## Security Notes

### Important Security Practices
1. **Never commit .env file**
   - Already in .gitignore
   - Contains sensitive API keys

2. **Use strong SECRET_KEY**
   - Generate new key for production
   ```python
   from django.core.management.utils import get_random_secret_key
   print(get_random_secret_key())
   ```

3. **Keep DEBUG=False in production**
   - Shows sensitive error information

4. **Validate all inputs**
   - Already using Pydantic
   - Keep validation strict

5. **Update dependencies regularly**
   ```bash
   pip list --outdated
   pip install --upgrade package_name
   ```

---

## Project Statistics

### Code Statistics
- **Total Files**: 20+
- **Python Files**: 10
- **HTML Templates**: 2
- **Documentation**: 5 markdown files
- **Lines of Code**: ~2000+

### Features Statistics
- **Database Tables**: 4
- **Pydantic Models**: 3
- **AI Features**: 7
- **URL Endpoints**: 6
- **Admin Models**: 4

### Test Coverage
- **Manual Tests**: 20+
- **Error Scenarios**: 7+
- **UI Components**: 10+

---

## Support & Resources

### Documentation
- Main: `README.md`
- Quick Guide: `PROJECT_GUIDE.md`
- Report Guide: `TECHNICAL_REPORT_GUIDE.md`
- Presentation: `PRESENTATION_SLIDES_GUIDE.md`

### External Resources
- Django Docs: https://docs.djangoproject.com/
- Gemini API: https://ai.google.dev/
- Pydantic: https://docs.pydantic.dev/
- Tailwind CSS: https://tailwindcss.com/

### Contact
- Mr. Fazeel: bsef23m043@pucit.edu.pk
- Ms Adan: bsef23m025@pucit.edu.pk
- Ms Momina: bsef23m024@pucit.edu.pk

---

## Final Pre-Submission Checklist

### Code
- [ ] All features working
- [ ] No console errors
- [ ] Error handling tested
- [ ] Logging functional
- [ ] Code commented

### Configuration
- [ ] .env has valid API key
- [ ] Database migrated
- [ ] Sample data works
- [ ] Admin accessible

### Documentation
- [ ] README.md complete
- [ ] Technical report written
- [ ] Presentation prepared
- [ ] All guides reviewed

### Testing
- [ ] Upload tested (valid & invalid)
- [ ] Chat functionality tested
- [ ] Delete tested
- [ ] Error scenarios tested
- [ ] UI responsive

### Presentation
- [ ] Demo practiced 3+ times
- [ ] Screenshots taken
- [ ] Backup video ready
- [ ] Q&A prepared
- [ ] Equipment tested

---

## You're All Set! 🎉

Your DoppleChat project is complete and ready for:
- ✅ Demonstration
- ✅ Presentation
- ✅ Viva Questions
- ✅ Submission

**Follow this guide, test thoroughly, and you'll excel!**

Good luck with your project! 🚀

