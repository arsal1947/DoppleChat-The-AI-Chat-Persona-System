# DoppleChat - Technical Report Guide
## AI Agent Semester Project

This document serves as a guide for completing the technical report (10-15 pages) as required by the semester project.

---

## 1. Introduction & Problem Statement

### Problem Statement
In today's digital age, people often want to preserve the communication style and personality of loved ones, friends, or historical figures. WhatsApp contains billions of conversations, but these are just text - they don't capture the essence of HOW someone communicates.

**DoppleChat** solves this problem by:
- Creating AI personas from WhatsApp chat exports
- Preserving communication styles, patterns, and personality traits
- Enabling interactive conversations with AI personas
- Maintaining conversation context and memory

### Project Goals
1. Parse and analyze WhatsApp chat exports
2. Generate detailed personality profiles using AI
3. Create conversational AI that mimics specific individuals
4. Provide a user-friendly interface for chat management
5. Implement robust error handling and logging

---

## 2. System Architecture

### High-Level Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     User Interface Layer                     │
│  (Django Templates + Tailwind CSS + JavaScript)             │
└───────────────────┬─────────────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────────────┐
│                    Application Layer                         │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │    Views     │  │  Validators  │  │   Utilities  │     │
│  │  (views.py)  │  │  (Pydantic)  │  │   (Parsers)  │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└───────────────────┬─────────────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────────────┐
│                   AI Processing Layer                        │
│  ┌─────────────────────────────────────────────────────┐   │
│  │          Google Gemini 2.5 Flash API                │   │
│  │  • Persona Generation  • Response Generation        │   │
│  │  • Pattern Analysis    • Intent Classification      │   │
│  └─────────────────────────────────────────────────────┘   │
└───────────────────┬─────────────────────────────────────────┘
                    │
┌───────────────────▼─────────────────────────────────────────┐
│                      Data Layer                              │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐     │
│  │   SQLite3    │  │   Logging    │  │  File System │     │
│  │   Database   │  │    System    │  │   (uploads)  │     │
│  └──────────────┘  └──────────────┘  └──────────────┘     │
└─────────────────────────────────────────────────────────────┘
```

### Component Descriptions

#### Frontend Layer
- **Technology**: Django Templates, Tailwind CSS, Vanilla JavaScript
- **Features**: Responsive design, real-time messaging, animations
- **Design Pattern**: WhatsApp-like interface

#### Backend Layer
- **Framework**: Django 6.0
- **Components**: Views, Models, URL routing, Middleware
- **Design Pattern**: MVT (Model-View-Template)

#### AI Layer
- **Model**: Google Gemini 2.5 Flash
- **Services**: Persona generation, response generation, classification

#### Data Layer
- **Database**: SQLite3
- **Logging**: File + Database logging
- **Storage**: Media files, chat exports

---

## 3. Agent Design & Reasoning Logic

### AI Agent Architecture

The DoppleChat agent implements multiple reasoning capabilities:

#### 3.1 Memory System (Agent Memory - Mandatory)
```
Conversation Memory:
├── Short-term Memory: Last 10 messages in context
├── Long-term Memory: All conversations in database
└── Persona Memory: Persistent personality profile
```

**Implementation:**
- `ConversationHistory` model stores all interactions
- Gemini API receives conversation context
- Responses maintain continuity across sessions

#### 3.2 Summarization (Feature 2)
- Analyzes 50+ messages to create persona summaries
- Generates 200+ word personality profiles
- Includes:
  - Communication style analysis
  - Tone and mood detection
  - Language pattern identification
  - Personality trait extraction

#### 3.3 Classification & Categorization (Feature 3)
- **Message Classification**: Greeting, question, statement, emotion, request
- **Sender Classification**: Separates messages by participant
- **Content Filtering**: Removes media, deleted messages

#### 3.4 Pattern Detection (Feature 4)
- **Emoji Usage Patterns**: High/medium/low frequency
- **Message Length Analysis**: Average character count
- **Punctuation Patterns**: Question/exclamation frequency
- **Writing Style**: Formal vs informal detection

#### 3.5 Additional Features
- **Trend Analysis**: Message statistics over time
- **Rule-based Decisions**: Pydantic validation rules
- **LLM Analysis**: Gemini-powered deep analysis

### Reasoning Flow

```
User Message Input
        ↓
[Validation] → Pydantic validation
        ↓
[Context Retrieval] → Load conversation history
        ↓
[Persona Context] → Load persona summary
        ↓
[AI Processing] → Gemini generates response
        ↓
[Validation] → Validate response quality
        ↓
[Storage] → Save to database
        ↓
Response to User
```

---

## 4. Dataset Description

### Data Source: WhatsApp Chat Exports

#### Format
- **File Type**: .txt (text file)
- **Encoding**: UTF-8 or UTF-16
- **Structure**: Timestamped messages with sender names

#### Sample Format
```
[12/15/2024, 10:30:15 AM] Ahmad: Hello, how are you?
[12/15/2024, 10:31:20 AM] Sara: I'm doing great, thanks!
[12/15/2024, 10:32:05 AM] Ahmad: That's wonderful to hear!
```

#### Data Processing Pipeline

1. **Upload**: User uploads WhatsApp .txt file
2. **Validation**: Check format and encoding
3. **Parsing**: Extract messages using regex patterns
4. **Filtering**: Remove system messages, media
5. **Extraction**: Get specific person's messages
6. **Analysis**: Compute writing style statistics
7. **Storage**: Save to database as JSON

#### Data Statistics
- **Input**: Raw WhatsApp chat export
- **Minimum Messages**: 3+ messages per chat
- **Extracted**: Person-specific messages only
- **Stored**: Cleaned messages + metadata

### Query Types Supported

1. **Search**: Find messages by person name
2. **Filter**: Remove media and system messages
3. **Extract**: Get specific sender's messages
4. **Analyze**: Compute writing patterns
5. **Categorize**: Group by message types

---

## 5. Algorithmic/LLM Methods Used

### 5.1 WhatsApp Parser Algorithm

```python
Algorithm: Extract Messages by Person
Input: chat_text, person_name
Output: cleaned_messages, statistics

1. Validate WhatsApp format using regex patterns
2. For each line in chat_text:
   a. Try matching with date-time-sender-message pattern
   b. If matched:
      - Extract sender and message
      - If sender == person_name:
        * Add to messages list
   c. If not matched:
      - Append to previous message (multi-line)
3. Clean messages:
   a. Remove media references
   b. Remove URLs
   c. Filter deleted messages
4. Analyze writing style
5. Return cleaned messages and stats
```

### 5.2 Persona Generation (Gemini AI)

```python
Algorithm: Generate Persona Summary
Input: person_name, messages[], writing_style{}
Output: persona_summary

1. Select sample (first 50 messages)
2. Construct detailed prompt with:
   - Person name
   - Writing statistics
   - Sample messages
   - Analysis requirements
3. Call Gemini API with prompt
4. Receive comprehensive persona summary
5. Validate summary quality (Pydantic)
6. Return persona_summary
```

### 5.3 Response Generation (Gemini AI)

```python
Algorithm: Generate Contextual Response
Input: user_message, persona_summary, conversation_history[]
Output: ai_response

1. Load last 10 messages from history
2. Construct context:
   - Persona profile
   - Recent conversation
   - Current user message
3. Build prompt:
   "You are [person_name]. Respond exactly as they would."
4. Call Gemini API
5. Receive response
6. Validate response (Pydantic)
7. Store in database
8. Return ai_response
```

### 5.4 Pattern Detection Algorithm

```python
Algorithm: Analyze Writing Style
Input: messages[]
Output: style_analysis{}

1. total_chars = sum(len(msg) for msg in messages)
2. avg_length = total_chars / len(messages)
3. emoji_count = count emojis in all messages
4. question_count = count '?' in messages
5. exclamation_count = count '!' in messages
6. Classify emoji_usage:
   - High: > 30% of messages
   - Medium: > 0% of messages
   - Low: 0 messages
7. Return {
   avg_message_length,
   emoji_usage,
   question_percentage,
   exclamation_percentage
}
```

### 5.5 LLM Integration Details

#### Gemini 2.5 Flash Model
- **Provider**: Google AI
- **Version**: gemini-2.0-flash-exp
- **Capabilities**:
  - Long context window (1M+ tokens)
  - Fast response generation
  - High-quality text understanding
  - Instruction following

#### Prompt Engineering Techniques

1. **Role Assignment**: "You are [person_name]"
2. **Context Provision**: Persona summary + history
3. **Instruction Clarity**: Detailed behavioral guidelines
4. **Output Specification**: Natural conversational responses
5. **Constraint Setting**: Stay in character, match style

---

## 6. Pydantic Models & Validation Strategy

### 6.1 ChatUploadValidator

```python
Purpose: Validate chat file uploads
Fields:
  - person_name: str (min=1, max=200)
  - file_content: str (min=10)
  - file_name: str (max=255)
Validations:
  - Person name not empty
  - File has minimum content
  - File has at least 3 lines
```

### 6.2 PersonaSummaryValidator

```python
Purpose: Ensure quality of generated personas
Fields:
  - person_name: str
  - cleaned_messages: List[str] (min_items=1)
  - persona_summary: str (min=50)
  - message_count: int (>=1)
  - writing_style_indicators: dict
Validations:
  - Summary minimum 50 characters
  - Must contain keywords: style/tone/personality
  - Message count >= 1
```

### 6.3 ConversationValidator

```python
Purpose: Validate chat messages
Fields:
  - user_message: str (min=1, max=5000)
  - ai_response: str (min=1)
  - chat_id: int (>=1)
  - timestamp: datetime
  - response_quality_score: float (0.0-1.0)
Validations:
  - Messages not empty
  - Proper trimming
  - Valid chat reference
```

### Validation Strategy

#### Level 1: Input Validation
- User uploads → ChatUploadValidator
- File format check
- Person name validation

#### Level 2: Processing Validation
- Extracted messages → List validation
- Format correctness
- Data completeness

#### Level 3: Output Validation
- Generated persona → PersonaSummaryValidator
- Quality checks
- Completeness verification

#### Level 4: Runtime Validation
- Every chat message → ConversationValidator
- Real-time validation
- Error prevention

### Error Handling Flow

```
User Input
    ↓
[Try Block]
    ↓
Pydantic Validation
    ↓ (Pass)          ↓ (Fail)
Process Data      ValidationError
    ↓                  ↓
Success           Log Error
                      ↓
                  User-Friendly Message
```

---

## 7. Database Schema & Logging Approach

### Database Tables

#### 1. chat_info
```sql
CREATE TABLE chat_info (
    chat_id INTEGER PRIMARY KEY AUTOINCREMENT,
    person_name VARCHAR(200) NOT NULL,
    cleaned_chat TEXT NOT NULL,
    persona_summary TEXT NOT NULL,
    raw_file_name VARCHAR(255) NOT NULL,
    created_at DATETIME NOT NULL,
    updated_at DATETIME NOT NULL
);
```

#### 2. selected_chat
```sql
CREATE TABLE selected_chat (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    active BOOLEAN NOT NULL DEFAULT 0,
    selected_at DATETIME NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES chat_info(chat_id) ON DELETE CASCADE
);
```

#### 3. conversation_history
```sql
CREATE TABLE conversation_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    user_message TEXT NOT NULL,
    ai_response TEXT NOT NULL,
    timestamp DATETIME NOT NULL,
    FOREIGN KEY (chat_id) REFERENCES chat_info(chat_id) ON DELETE CASCADE
);
```

#### 4. system_logs
```sql
CREATE TABLE system_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    level VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    module VARCHAR(100) NOT NULL,
    timestamp DATETIME NOT NULL,
    extra_data JSON
);
```

### Logging Strategy

#### Two-Level Logging System

**Level 1: File Logging**
- Location: `logs/dopplechat.log`
- Rotation: 10MB max, 5 backups
- Format: `timestamp - module - level - function - message`

**Level 2: Database Logging**
- Table: `system_logs`
- Levels: INFO, WARNING, ERROR
- Includes: module, timestamp, extra metadata

#### Logging Points

1. **Upload Events**
   ```python
   log_to_database('INFO', f'Chat uploaded for {person_name}', 'views')
   ```

2. **AI Operations**
   ```python
   log_to_database('INFO', 'Persona summary generated', 'gemini_service')
   ```

3. **Errors**
   ```python
   log_to_database('ERROR', f'Parse failed: {error}', 'whatsapp_parser')
   ```

4. **User Actions**
   ```python
   logger.info(f"Chat {chat_id} selected by user")
   ```

---

## 8. UI Design

### Design Philosophy
- **Familiar**: WhatsApp-like interface
- **Modern**: Tailwind CSS styling
- **Professional**: Clean, polished look
- **Responsive**: Works on all screen sizes
- **Animated**: Smooth transitions

### UI Components

#### 1. Header Bar
- App logo and name
- Upload chat button
- Gradient green background

#### 2. Chat Sidebar
- List of all personas
- Avatar initials
- Chat metadata
- Delete buttons
- Active chat highlighting

#### 3. Main Chat Area
- Message display area
- User messages (right, green)
- AI messages (left, gray)
- Typing indicator
- Scroll functionality

#### 4. Input Area
- Text input field
- Send button
- Rounded, modern design

#### 5. Modals
- Upload chat modal
- Persona info modal
- Overlay backgrounds

### Color Scheme
- **Primary**: Green (#10b981)
- **Secondary**: Blue (#3b82f6)
- **Dark**: Gray (#1f2937)
- **Accent**: Purple, Pink

### Animations
- Fade-in for messages
- Slide-in for modals
- Bounce for loading
- Gradient animations

---

## 9. Testing & Evaluation

### Test Cases

#### 1. Upload Functionality
- ✅ Upload valid WhatsApp chat
- ✅ Upload invalid format (error)
- ✅ Upload with wrong person name (error)
- ✅ Upload empty file (error)
- ✅ Upload non-text file (error)

#### 2. Chat Functionality
- ✅ Send message to AI
- ✅ Receive contextual response
- ✅ Multiple message exchange
- ✅ Context preservation
- ✅ Persona consistency

#### 3. Data Management
- ✅ Select different chats
- ✅ Delete chat
- ✅ View conversation history
- ✅ Database persistence

#### 4. Error Handling
- ✅ Network errors
- ✅ API failures
- ✅ Invalid inputs
- ✅ Database errors

### Performance Metrics

| Metric | Value |
|--------|-------|
| Upload processing time | 5-10 seconds |
| Response generation time | 2-5 seconds |
| Database query time | < 100ms |
| Page load time | < 1 second |

---

## 10. Challenges & Limitations

### Challenges

#### 1. WhatsApp Format Variations
- **Problem**: Different export formats across regions/versions
- **Solution**: Multiple regex patterns, format detection

#### 2. Persona Quality
- **Problem**: Ensuring AI generates quality personas
- **Solution**: Pydantic validation with quality checks

#### 3. Context Management
- **Problem**: Maintaining conversation coherence
- **Solution**: Database-backed history with sliding window

#### 4. Error Handling Complexity
- **Problem**: Many points of failure
- **Solution**: Try-catch at every level, comprehensive logging

### Limitations

1. **Language Support**: Currently optimized for English
2. **File Size**: Large chats may take longer to process
3. **API Dependency**: Requires internet for AI features
4. **Single User**: No multi-user authentication system
5. **Media**: Cannot process images/videos from chats

---

## 11. Conclusion & Future Enhancements

### Conclusion

DoppleChat successfully demonstrates:
- ✅ AI reasoning and decision-making
- ✅ Advanced data processing
- ✅ Task automation
- ✅ Comprehensive logging
- ✅ Output validation

The system effectively creates AI personas from WhatsApp chats, maintaining personality traits and communication styles through intelligent memory and context management.

### Future Enhancements

#### Short-term (3-6 months)
1. **Multi-language Support**: Support for Urdu, Arabic, etc.
2. **Voice Messages**: Analyze speech patterns
3. **Advanced Analytics**: Visual dashboards
4. **Export Feature**: Download conversations

#### Medium-term (6-12 months)
1. **Multi-user System**: Authentication and user accounts
2. **Cloud Deployment**: Host on AWS/Heroku
3. **Mobile App**: React Native mobile version
4. **Real-time Sync**: WebSocket connections

#### Long-term (1+ years)
1. **Video Analysis**: Extract personality from videos
2. **Multi-agent Chats**: Group conversations
3. **Custom Training**: Fine-tune models
4. **Commercial Version**: SaaS product

### Impact & Applications

1. **Personal**: Preserve memories of loved ones
2. **Business**: Customer service persona training
3. **Education**: Historical figure interactions
4. **Entertainment**: Chat with fictional characters
5. **Research**: Communication pattern studies

---

## References

1. Django Documentation: https://docs.djangoproject.com/
2. Google Gemini API: https://ai.google.dev/
3. Pydantic Documentation: https://docs.pydantic.dev/
4. Tailwind CSS: https://tailwindcss.com/
5. WhatsApp Export Format: WhatsApp Official Documentation

---

**Note**: This guide provides the structure and content for your 10-15 page technical report. Expand each section with:
- Screenshots of the application
- More detailed code examples
- Additional diagrams and flowcharts
- Test results and outputs
- Personal insights and learnings

